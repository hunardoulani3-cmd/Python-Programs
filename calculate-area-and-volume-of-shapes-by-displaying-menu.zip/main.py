# Use switch case structure to calculate area or volume of different shapes.
# Display the menu to the user and ask for the shape and dimensions. Then calculate and display the area or volume accordingly.
# Menu: 1. Area of Circle, 2. Area of Rectangle, 3. Area of Triangle, 4. Area of Square, 5. Area of Parallelogram, 6. Volume of Cube, 7. Volume of Cuboid, 8. Volume of Sphere, 9. Volume of Cylinder, 10. Volume of Cone.

print("Menu:")
print("1. Area of Circle")
print("2. Area of Rectangle")
print("3. Area of Triangle")
print("4. Area of Square")
print("5. Area of Parallelogram")
print("6. Volume of Cube")
print("7. Volume of Cuboid")
print("8. Volume of Sphere")
print("9. Volume of Cylinder")
print("10. Volume of Cone")
shape = int(input("Enter the number of the shape to calculate area or volume: "))



def calculate_area(shape, *args):
    if shape == 1:
        radius = args[0]
        area = 3.14 * radius * radius
        return area
    elif shape == 2:
        length = args[0]
        breadth = args[1]
        area = length * breadth
        return area
    elif shape == 3:
        base = args[0]
        height = args[1]
        area = 0.5 * base * height
        return area
    elif shape == 4:
        side = args[0]
        area = side * side
        return area
    elif shape == 5:
        base = args[0]
        height = args[1]
        area = base * height
        return area
    else:
        return "Invalid shape"

def calculate_volume(shape, *args):
    if shape == 6:
        side = args[0]
        volume = side * side * side
        return volume
    elif shape == 7:
        length = args[0]
        breadth = args[1]
        height = args[2]
        volume = length * breadth * height
        return volume
    elif shape == 8:
        radius = args[0]
        volume = (4/3) * 3.14 * radius * radius * radius
        return volume
    elif shape == 9:
        radius = args[0]
        height = args[1]
        volume = 3.14 * radius * radius * height
        return volume
    elif shape == 10:
        radius = args[0]
        height = args[1]
        volume = (1/3) * 3.14 * radius * radius * height
        return volume

    else:
        return "Invalid shape"
    
if shape in [1, 2, 3, 4, 5]:
    if shape == 1:
        radius = float(input("Enter the radius of the circle: "))
        print("Area of the circle is: ", calculate_area(shape, radius))
    elif shape == 2:
        length = float(input("Enter the length of the rectangle: "))
        breadth = float(input("Enter the breadth of the rectangle: "))
        print("Area of the rectangle is: ", calculate_area(shape, length, breadth))
    elif shape == 3:
        base = float(input("Enter the base of the triangle: "))
        height = float(input("Enter the height of the triangle: "))
        print("Area of the triangle is: ", calculate_area(shape, base, height)) 
    elif shape == 4:
        side = float(input("Enter the side of the square: "))
        print("Area of the square is: ", calculate_area(shape, side))
    elif shape == 5:
        base = float(input("Enter the base of the parallelogram: "))
        height = float(input("Enter the height of the parallelogram: "))
        print("Area of the parallelogram is: ", calculate_area(shape, base, height))
elif shape in [6, 7, 8, 9, 10]:
    if shape == 6:
        side = float(input("Enter the side of the cube: "))
        print("Volume of the cube is: ", calculate_volume(shape, side))
    elif shape == 7:
        length = float(input("Enter the length of the cuboid: "))
        breadth = float(input("Enter the breadth of the cuboid: "))
        height = float(input("Enter the height of the cuboid: "))
        print("Volume of the cuboid is: ", calculate_volume(shape, length, breadth, height))
    elif shape == 8:
        radius = float(input("Enter the radius of the sphere: "))
        print("Volume of the sphere is: ", calculate_volume(shape, radius))
    elif shape == 9:
        radius = float(input("Enter the radius of the cylinder: "))
        height = float(input("Enter the height of the cylinder: "))
        print("Volume of the cylinder is: ", calculate_volume(shape, radius, height))
    elif shape == 10:
        radius = float(input("Enter the radius of the cone: "))
        height = float(input("Enter the height of the cone: "))
        print("Volume of the cone is: ", calculate_volume(shape, radius, height))

else:    
    print("Invalid shape")