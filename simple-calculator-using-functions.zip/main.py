#Perform addition,subtraction,multiplication and division of two numbers using functions.

def add(a, b):
    return a + b
def subtract(a, b):
    return a - b
def multiply(a, b):
    return a * b
def divide(a, b):
    if b != 0:
        return a // b
    else:
        return "Division by zero is not allowed."
num1 = int(input("Enter the first number: "))
num2 = int(input("Enter the second number: "))
print("Addition of", num1, "and", num2, "is", add(num1, num2))
print("Subtraction of", num1, "and", num2, "is", subtract(num1, num2))
print("Multiplication of", num1, "and", num2, "is", multiply(num1, num2))
print("Division of", num1, "and", num2, "is", divide(num1, num2))