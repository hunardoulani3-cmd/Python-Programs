#Write a recursive function to check whether a string is a palindrome.

def is_palindrome(s):
    # Base case: if the string is empty or has one character, it's a palindrome
    if len(s) <= 1:
        return "Palindrome"
    # Recursive case: check the first and last characters, and then check the substring in between
    if s[0] == s[-1]:
        return is_palindrome(s[1:-1])
    else:
        return "Not a Palindrome"
    
s=input("Enter a string: ")
print(is_palindrome(s))