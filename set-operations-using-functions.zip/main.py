#Perform set operations using functions.

def union(set1, set2):
    return set1 | set2
def intersection(set1, set2):
    return set1 & set2
def difference(set1, set2):
    return set1 - set2
def symmetric_difference(set1, set2):
    return set1 ^ set2
n1=int(input("Enter the number of elements in set 1: "))
list1 = []
for i in range(n1):
    element = input("Enter element : ")
    list1.append(element)
n2=int(input("Enter the number of elements in set 2: "))
list2 = []
for i in range(n2):
    element = input("Enter element : ")
    list2.append(element)
set1 = set(list1)
set2 = set(list2)
print("Set 1:", set1)
print("Set 2:", set2)
print("Union of the sets is", union(set1, set2))
print("Intersection of the sets is", intersection(set1, set2))
print("Difference (Set 1 - Set 2):", difference(set1, set2))
print("Symmetric Difference of the sets is", symmetric_difference(set1, set2))


#function to check if one set is a subset of another set and whether it is a superset.

def is_subset(set1, set2):
    return set1.issubset(set2)

def is_superset(set1, set2):
    return set1.issuperset(set2)

n1=int(input("Enter the number of elements in set 1 to check if it is a subset of set 2: "))
list1 = []
for i in range(n1):
    element = input("Enter element : ")
    list1.append(element)
n2=int(input("Enter the number of elements in set 2: "))
list2 = []
for i in range(n2):
    element = input("Enter element : ")
    list2.append(element)
set1 = set(list1)
set2 = set(list2)

if is_subset(set1, set2):
    print("Set 1 is a subset of Set 2")
else:
    print("Set 1 is not a subset of Set 2")

n1=int(input("Enter the number of elements in set 1 to check if it is a superset of set 2: "))
list1 = []
for i in range(n1):
    element = input("Enter element : ")
    list1.append(element)
n2=int(input("Enter the number of elements in set 2: "))
list2 = []
for i in range(n2):
    element = input("Enter element : ")
    list2.append(element)
set1 = set(list1)
set2 = set(list2)

if is_superset(set1, set2):
    print("Set 1 is a superset of Set 2")
else:
    print("Set 1 is not a superset of Set 2")


#function to check if an element is a member of a set.
def is_member(element, set1):
    return element in set1
n1=int(input("Enter the number of elements in set 1: "))
list1 = []
for i in range(n1):
    element = input("Enter element {}: ".format(i + 1))
    list1.append(element)
set1 = set(list1)
element = input("Enter an element to check if it is present in Set 1: ")
if is_member(element, set1):
    print("{} is a member of Set 1".format(element))
else:
    print("{} is not a member of Set 1".format(element))

#function to check number of elements in a set.
def count_elements(set1):
    return len(set1)
set1 = set(input("Enter elements of the set separated by comma: ").split(","))
print("Number of elements in the set is:", count_elements(set1))

#taking a list and converting it to a set to remove duplicates.
def remove_duplicates(list1):
    return set(list1)
n=int(input("Enter the number of elements in the list: "))
list1 = []
for i in range(n):
    element = input("Enter element : ")
    list1.append(element)
set1=remove_duplicates(list1)
print("Set after removing duplicates is", set1)

#function that finds all possible subsets of a given set.
def find_power_set(set1):
    power_set = []
    for i in range(2**len(set1)):
        subset = {list(set1)[j] for j in range(len(set1)) if (i & (1 << j))}
        power_set.append(subset)
    return power_set

set1 = set(input("Enter elements of the set separated by comma: ").split(","))
print("Power set of the given set is:", find_power_set(set1))