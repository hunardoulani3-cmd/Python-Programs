# Checks strength of password 
# Strong password should contain at least 8 characters, including uppercase letters, lowercase letters, numbers, and special characters.
# Moderate strength means three or four conditions are satisfied and weak strength means one or two conditions are satisfied.
import re
password = input("Enter Password: ")
#The conditions are
c1=len(password) >= 8
c2=re.search(r'[A-Z]', password) is not None
c3=re.search(r'[a-z]', password) is not None
c4=re.search(r'[0-9]', password) is not None
c5=re.search(r'[@$!%*?&]', password) is not None

if (c1 and c2 and c3 and c4 and c5):
    print("Password Strength: Strong")

elif(c1 and c2 and c3 and c4 or c1 and c2 and c3 and c5 or c1 and c2 and c4 and c5 
     or c1 and c3 and c4 and c5 or c2 and c3 and c4 and c5 or c1 and c2 and c3 
     or c1 and c2 and c4 or c1 and c2 and c5 or c1 and c3 and c4 or c1 and c3 and c5 
     or c1 and c4 and c5 or c2 and c3 and c4 or c2 and c3 and c5 or c2 and c4 and c5 or c3 and c4 and c5):
    print("Password Strength: Moderate")

else:
    print("Password Strength: Weak")